using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CAT_Script : MonoBehaviour
{ 

    Renderer renderer;
    bool beenSeen = false;
    [SerializeField] GameObject MC;
    bool TriggerActive = false;
    bool Meowed = false;
    [SerializeField] AudioSource Audio;
    [SerializeField] GameObject Alert;

    float timer = 0;


    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            TriggerActive = true;
            Alert.SetActive(true);
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            TriggerActive = false;
            Alert.SetActive(false);
        }
    }





    private void Start()
    {
        renderer = GetComponent<Renderer>();
    }

    private void Update()
    {
        //if the current cat is active, 
        if (isActiveAndEnabled)
        {
            //check the distance from the player and if the cat is visble
            if (renderer.isVisible && Vector3.Distance(transform.position, MC.transform.position) < 50)
                beenSeen = true;

            //Play the attached audio
            if (Input.GetButtonDown("Interact") && TriggerActive && !Meowed)
            {
                Meowed = true;
                FadeAudioSource.StartFade(Audio, 0.2f,0.05f);
                Audio.Play();

            }
        }


        //timer for interacting with the cat
        if(Meowed == true)
        {
            timer += Time.deltaTime;
            if(timer > 2)
            {
                Meowed = false;
                timer = 0;
            }
        }

      
    }

    //Checks to see if the cat is in view of the rendering camera
    public bool CheckVisible()
    {
        if (!beenSeen)
            return true;
        else
            return renderer.isVisible;
    }

}
