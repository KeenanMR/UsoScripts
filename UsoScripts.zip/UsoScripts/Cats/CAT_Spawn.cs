using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CAT_Spawn : MonoBehaviour
{
    [SerializeField] GameObject CurrentCat;

    [SerializeField] GameObject[] AllCats;

    [SerializeField] GameObject MC;



    private void Start()
    {
        if(!CurrentCat.activeSelf)
        CurrentCat.SetActive(true);
    }


    private void Update()
    {
        //if the current cat is not visible to the player call NewCat()
        if(!CurrentCat.GetComponent<CAT_Script>().CheckVisible())
        {
            NewCat();
        }
    }

    public void NewCat()
    {

        CurrentCat.SetActive(false);

        //Get a random new cat and check that it is not the same cat
        int rand = Random.Range(0, AllCats.Length);

        while (AllCats[rand] == CurrentCat)
            rand = Random.Range(0, AllCats.Length);

        CurrentCat = AllCats[rand];
        CurrentCat.SetActive(true);

        //If the current cat is too far from the player, call the function again
        if (Vector3.Distance(MC.transform.position, CurrentCat.transform.position) < 30)
        {
            NewCat();
        }

    }



}
