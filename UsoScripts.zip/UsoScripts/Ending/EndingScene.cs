using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Yarn.Unity;
using UnityEngine.SceneManagement;

public class EndingScene : MonoBehaviour
{
 
        int index;

    [Header("UI")]
    [SerializeField] DialogueRunner runner;

    [Header("Image Refs")]
    [SerializeField] GameObject[] NPCs;
    [SerializeField] GameObject Tsuki;

    // Start is called before the first frame update
    void Start()
    {

        NPCs[index].SetActive(true);
    }

    //Loads a diffferent scene depending on if the player is on the first or second loop
    [YarnCommand("end")]
    public void EndSpeech()
    {

        if (MainMenuData.RunOnce)
        {
            SceneManager.LoadScene("Tsuki Ending Loop");
            MainMenuData.RunOnce = false;
            return;
        }

        MainMenuData.RunOnce = true;
        SceneManager.LoadScene("mainmenu");
    }

    [YarnCommand("end_loop")]
    public void EndSpeechLoop()
    {
        MainMenuData.RunOnce = false;
        SceneManager.LoadScene("mainmenu");
    }


    //Sets the UI to the MC's character images
    [YarnCommand("tsuki_talk")]
    public void TsukiTalk()
    {
        NPCs[index].SetActive(false);
        Tsuki.SetActive(true);
    }


    //Chooses which yarn node to run based on who the player chose
    [YarnCommand("move_node")]
    public void MoveNode()
    {
        runner.Stop();
        index = MainMenuData.Choice;

        switch (index)
        {
            case 0:

                if(!MainMenuData.RunOnce)
                runner.StartDialogue("Maid");
                else
                    runner.StartDialogue("Maid_2");

                break;
            case 1:

                runner.StartDialogue("Lord");

                break;
            case 2:

                runner.StartDialogue("Lady");

                break;
            case 3:
               
                if (!MainMenuData.RunOnce)
                    runner.StartDialogue("LittleMiss");
                else
                    runner.StartDialogue("LittleMiss_2");

                break;

            case 4:
                runner.StartDialogue("Cook_2");
                break;

            case 5:
                runner.StartDialogue("Gardener_2");
                break;


            default:
                break;
        }
    }

}
