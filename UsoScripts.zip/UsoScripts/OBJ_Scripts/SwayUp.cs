using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SwayUp : MonoBehaviour
{
    float angle;
    float change = 0;
    float yPos;
    bool increasing = true;

    public bool star;

    private void Start()
    {
        yPos = this.transform.position.y;
        angle = Random.Range(450, 1350);
    }

    // Update is called once per frame
    void Update()
    {
        if (increasing)
            angle++;
        else
            angle--;

        //Make an object swap up and down over time
        if (!star)
        {
            float rads = angle / 10 * Mathf.Deg2Rad;
            change = Mathf.Sin(rads);
            this.transform.position = new Vector3(this.transform.position.x, yPos + change * 2, this.transform.position.z);
            if (angle > 1350 && increasing)
                increasing = false;

            if (angle < 550 && !increasing)
                increasing = true;
        }

        if (star)
        {
            float rads = angle / 8 * Mathf.Deg2Rad;
            change = Mathf.Sin(rads);
            this.transform.position = new Vector3(this.transform.position.x, yPos + change * 2, this.transform.position.z);
            if (angle > 1350 && increasing)
                increasing = false;

            if (angle < 450 && !increasing)
                increasing = true;
        }

    }
}