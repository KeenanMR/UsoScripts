using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LightFlicker : MonoBehaviour
{

    public bool isFlickering = false;
    public float flickerDelay;
    float flickerIntensity;

    // Update is called once per frame
    void Update()
    {
        if(!isFlickering)
        {
            StartCoroutine(RandomFlicker());
        }
    }

    //Causes a light to randomly and partially flicker on and off
    IEnumerator RandomFlicker()
    {
        isFlickering = true;
        flickerDelay = Random.Range(0.1f, 0.2f);
        gameObject.GetComponent<Light>().intensity = Mathf.Lerp(gameObject.GetComponent<Light>().intensity, Random.Range(1, 100), flickerDelay)/10;
        yield return new WaitForSeconds(flickerDelay);
        isFlickering = false;


    }
   
}
