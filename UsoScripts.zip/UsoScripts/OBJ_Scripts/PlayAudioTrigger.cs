using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayAudioTrigger : MonoBehaviour
{

    [SerializeField] AudioSource OBJ_Aud;
    float OBJ_Volume = 0.05f;
    bool OBJ_On = false;

    //Play an audio track when the player enters a trigger
    private void OnTriggerEnter(Collider other)
    {
        OBJ_Aud.Play();
        OBJ_On = true;
        StartCoroutine(FadeAudioSource.StartFade(OBJ_Aud, 1, OBJ_Volume));
    }

    //Reset an audio track when the player leaves a trigger
    private void OnTriggerExit(Collider other)
    {
        OBJ_Aud.Stop();
        OBJ_On = false;
        StartCoroutine(FadeAudioSource.StartFade(OBJ_Aud, 1, 0));
    }

    //Updates the volume of any attached auido when the settings are changed
    public void UpdateVolume(float newMasterVolume, float newMusicVolume, float newSFXVolume)
    {
        newMasterVolume = newMasterVolume / 100;
        newMusicVolume = newMusicVolume / 100;
        newSFXVolume = newSFXVolume / 100;


        OBJ_Volume = newMasterVolume * newSFXVolume;

        if (OBJ_On)
        {
            OBJ_Aud.volume = OBJ_Volume;
        }

    }

}



