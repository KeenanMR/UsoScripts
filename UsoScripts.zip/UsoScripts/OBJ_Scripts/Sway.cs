using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sway : MonoBehaviour
{
    float angle;
    float change = 0;
    float xPos;
    bool increasing = true;


    private void Start()
    {
        xPos = this.transform.position.x;
        angle = Random.Range(450, 1350);
    }

    // Update is called once per frame
    void Update()
    {
        //Make an object swap left and right over time
        if (increasing)
        angle++;
        else
        angle--;

        float rads = angle/10 * Mathf.Deg2Rad;
        change = Mathf.Sin(rads);
        this.transform.position = new Vector3(xPos + change*2, this.transform.position.y, this.transform.position.z);
        if (angle > 1000 && increasing)
            increasing = false;

        if (angle < 550 && !increasing)
            increasing = true;

    }
}
