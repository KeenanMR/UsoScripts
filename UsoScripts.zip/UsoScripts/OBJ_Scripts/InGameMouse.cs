using UnityEngine.SceneManagement;
using UnityEngine;
using System.IO;

public class InGameMouse : MonoBehaviour
{

    //Check Data
    public string OBJ_TextRef_Path;
    public Material OBJ_NewMat;
    Material OBJ_StarterMat;
    [SerializeField] int OBJ_Index;

    //Sets initial mat
    private void Start()
    {
        OBJ_StarterMat = GetComponent<Renderer>().material;
    }
    //Change the objects material when hovered by the mouse
    private void OnMouseEnter()
    {
        GetComponent<Renderer>().material = OBJ_NewMat;
    }

    //When the object is clicked load the ending
    private void OnMouseOver()
    {
        

            if (Input.GetButtonDown("Click"))
            {
                MainMenuData.Choice = OBJ_Index;
                SceneManager.LoadScene("Ending");

            }
    }
    //Change the objects material when unhovered by the mouse
    private void OnMouseExit()
    {
        GetComponent<Renderer>().material = OBJ_StarterMat;

    }
}
