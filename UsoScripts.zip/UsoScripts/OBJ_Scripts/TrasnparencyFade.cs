using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TrasnparencyFade : MonoBehaviour
{

    Skybox OBJ_SkyboxRef;
    float OBJ_Transparency = 1.0f;
    // Start is called before the first frame update
    void Start()
    {
        OBJ_SkyboxRef = GetComponent<Skybox>();
    }

    // Update is called once per frame
    void Update()
    {
        //Fade effect for applied objects
        if(OBJ_Transparency > 0)
        OBJ_Transparency -= 0.001f;

        OBJ_SkyboxRef.material.color = new Color(OBJ_SkyboxRef.material.color.r, OBJ_SkyboxRef.material.color.g, OBJ_SkyboxRef.material.color.b, OBJ_Transparency);
    }
}
