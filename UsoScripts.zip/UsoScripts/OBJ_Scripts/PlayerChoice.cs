using UnityEngine;

public class PlayerChoice : MonoBehaviour
{
    //Check Data
    public Material OBJ_NewMat;
    Material OBJ_StarterMat;
    public MC_Controller MC_ScriptReference;
    public int OBJ_ChoiceIndex;

    //Sets initial mat
    private void Start()
    {
        OBJ_StarterMat = GetComponent<Renderer>().material;
    }

    //Change the objects material when hovered by the mouse
    private void OnMouseEnter()
    {
        if(MC_ScriptReference.MC_MakingChoice)
        GetComponent<Renderer>().material = OBJ_NewMat;
    }

    //When the object is clicked start a new node in yarnspinner and reset the material
    private void OnMouseOver()
    {
        if (Input.GetButtonDown("Click"))
        {
            if (MC_ScriptReference.MC_MakingChoice)
            {
                MC_ScriptReference.MakeChoice(OBJ_ChoiceIndex);
                GetComponent<Renderer>().material = OBJ_StarterMat;
            }


        }
    }

    //Change the objects material when unhovered by the mouse
    private void OnMouseExit()
    {
        if (MC_ScriptReference.MC_MakingChoice)
            GetComponent<Renderer>().material = OBJ_StarterMat;

    }
}
