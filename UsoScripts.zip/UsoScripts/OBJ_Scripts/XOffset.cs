using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class XOffset : MonoBehaviour
{
    float offset;

    // Start is called before the first frame update
    void Start()
    {
        //Update an objects x-positions using a random perlin noise value
        offset = Mathf.PerlinNoise(Random.Range(0, 100), Random.Range(0, 100));

        float check = Random.Range(0, 100);

        if (check > 50)
            this.transform.position = new Vector3(this.transform.position.x + offset * 2, this.transform.position.y, this.transform.position.z);
        else
            this.transform.position = new Vector3(this.transform.position.x - offset * 2, this.transform.position.y, this.transform.position.z);
    }

   

}
