using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RandomPlacement : MonoBehaviour
{

    /// <summary>
    ///  LEGACY
    ///  USED FOR TREE PLACEMENT IN EARLY DEVELOPMENT
    /// </summary>

    float offset;
    public bool bush;
    public bool bigBush;

    // Start is called before the first frame update
    void Start()
    {
        //Update an objects x-positions using a random perlin noise value
        offset = Mathf.PerlinNoise(Random.Range(0, 100), Random.Range(0, 100));

        float check = Random.Range(0, 100);

        if (check > 50)
        this.transform.position = new Vector3(this.transform.position.x + offset * 10, this.transform.position.y, this.transform.position.z);
        else
        this.transform.position = new Vector3(this.transform.position.x - offset * 10, this.transform.position.y, this.transform.position.z);


        //Update an objects z-positions using a random perlin noise value
        float check2 = Random.Range(0, 100);
        if (check2 > 50)
            this.transform.position = new Vector3(this.transform.position.x, this.transform.position.y, this.transform.position.z + offset * 10);
        else
            this.transform.position = new Vector3(this.transform.position.x, this.transform.position.y, this.transform.position.z - offset * 10);


        //Update an objects scale using random values
        float check3 = Random.Range(0, 100);
        float check4 = Random.Range(0, 100);
        if (check4 > 50)
        {
            if (check3 > 50 && check3 < 90)
                this.transform.localScale = new Vector3(1 + offset / 5, 1 + offset / 5, 1 + offset / 5);
            else if (check3 < 50)
                this.transform.localScale = new Vector3(-1 + offset / 5, 1 + offset / 5, 1 + offset / 5);
            else
            {
                if (!bush)
                {
                    this.transform.localScale = new Vector3(-3 + offset / 2, 3 + offset / 2, 3 + offset / 2);
                    this.transform.position = new Vector3(this.transform.position.x, this.transform.position.y + 6, this.transform.position.z);
                }
            }
        }
        else
        {
            if (check3 > 50)
                this.transform.localScale = new Vector3(1 - offset/ 5, 1 - offset / 5, 1 - offset / 5);
            else
                this.transform.localScale = new Vector3(-1 - offset / 5, 1 - offset / 5, 1 - offset / 5);
        }

        if(bigBush)
        {

            this.transform.localScale = this.transform.localScale - new Vector3(1 - offset*2, 1 - offset*2 , 1 - offset*2 );
            this.transform.position = new Vector3(this.transform.position.x, this.transform.position.y - 3, this.transform.position.z);
        }

    }

}

