
using UnityEngine;
using TMPro;
using System.IO;
using UnityEngine.SceneManagement;

public class NPC_PoliceAccusation : MonoBehaviour
{

    //Check Data
    public string OBJ_TextRef_Path;
    public GameObject OBJ_ChoiceObject;
    public GameObject[] OBJ_ChoiceOptions; 

    bool[] NPC_IndexInteractions = new bool[7];
    bool MC_NoInteractions = true;

    public string[] NPC_Names;


    private void Start()
    {

        for(int i = 0; i < NPC_IndexInteractions.Length; i++)
        {
            NPC_IndexInteractions[i] = false;
        }

    }

    private void Update()
    {
        return;
    }

    public void Accuse()
    {
        int choiceIndex = 0;
        

        for (int i = 0; i < NPC_IndexInteractions.Length; i++)
        {
            if(NPC_IndexInteractions[i])
            {
                MC_NoInteractions = false;
            }

            //Sets the acive state and text of the in game player choices based on previous inmteractions
            if (choiceIndex < 4)
            {
              if (NPC_IndexInteractions[i])
                {
                    switch (i)
                    {
                        case 0:
                            OBJ_ChoiceOptions[i].SetActive(true);
                            TMP_Text textRef = OBJ_ChoiceOptions[i].GetComponentInChildren(typeof(TMP_Text)) as TMP_Text;
                            textRef.text = NPC_Names[i];
                            break;
                        case 1:
                            OBJ_ChoiceOptions[i].SetActive(true);
                            TMP_Text textRef1 = OBJ_ChoiceOptions[i].GetComponentInChildren(typeof(TMP_Text)) as TMP_Text;
                            textRef1.text = NPC_Names[i];
                            break;
                        case 2:
                            OBJ_ChoiceOptions[i].SetActive(true);
                            TMP_Text textRef2 = OBJ_ChoiceOptions[i].GetComponentInChildren(typeof(TMP_Text)) as TMP_Text;
                            textRef2.text = NPC_Names[i];
                            break;
                        case 3:
                            OBJ_ChoiceOptions[i].SetActive(true);
                            TMP_Text textRef3 = OBJ_ChoiceOptions[i].GetComponentInChildren(typeof(TMP_Text)) as TMP_Text;
                            textRef3.text = NPC_Names[i];
                            break;
                        case 4:
                            OBJ_ChoiceOptions[i].SetActive(true);
                            TMP_Text textRef4 = OBJ_ChoiceOptions[i].GetComponentInChildren(typeof(TMP_Text)) as TMP_Text;
                            textRef4.text = NPC_Names[i];
                            break;
                        case 5:
                            OBJ_ChoiceOptions[i].SetActive(true);
                            TMP_Text textRef5 = OBJ_ChoiceOptions[i].GetComponentInChildren(typeof(TMP_Text)) as TMP_Text;
                            textRef5.text = NPC_Names[i];
                            break;

                        default:
                            break;
                    }
                }

            }
        }


    }

    public void Checkoff(int NPC_Index)
    {
        NPC_IndexInteractions[NPC_Index] = true;
    }


}
