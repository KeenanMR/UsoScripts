using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Yarn.Unity;
using TMPro;
using DG.Tweening;
public class NPC_PoliceScript : MonoBehaviour
{

    [SerializeField] DialogueRunner NPC_Runner;
    [SerializeField] DialogueAdvanceInputNew DIAG_InputRef;
    [SerializeField] MC_Controller MC_ReferenceScript;
    [SerializeField] GameObject NPC_PlayerSocket;
    [SerializeField] LineView NPC_LineView;
    [SerializeField] LineView MC_LineView;
    [SerializeField] LineView UI_LineView;
    CanvasGroup UI_LineViewCanvas;
    [SerializeField] OptionsListView UI_OptionsLineView;
    CanvasGroup UI_OptionsLineViewCanvas;
    [SerializeField] GameObject MC_ChoiceOBJ;
    [SerializeField] GameObject NPC_TextBox;
    [SerializeField] TMP_Text[] MC_ChoiceTexts;
    [SerializeField] TMP_Text MC_Text;
    [SerializeField] TMP_Text NPC_Text;
    [SerializeField] Toggle UI_TextToggle;

    [Header("UI Image References")]
    [SerializeField] Image UI_CharLineImage;
    [SerializeField] Image UI_CharLineImage2;
    [SerializeField] Image UI_CharBGImage;
    [SerializeField] Image UI_CharSpriteImage;
    [SerializeField] Image UI_CharDetailImage;
    [SerializeField] Image UI_CharDetailImage2;
    [SerializeField] GameObject UI_ClueIndicator;

    [Header("UI Image Sprites")]
    [SerializeField] Sprite UI_CharLine;
    [SerializeField] Sprite UI_CharBG;
    [SerializeField] Sprite UI_CharSprite;
    [SerializeField] Sprite UI_CharDetail;
    [SerializeField] Sprite UI_CharDetail2;

    [Header("NPC Audio")]
    [SerializeField] AudioClip NPC_Jingle;
    [SerializeField] AudioSource NPC_Clock;


    [Header("Model")]
    [SerializeField] GameObject NPC_ModelRef;
    [SerializeField] GameObject NPC_Alert;

    [Header("Spawn Locations")]
    [SerializeField] Vector3[] NPC_SpawnLocations;


    [Header("Police Accusation Script Reference")]
    public NPC_PoliceAccusation NPC_PoliceAccusation_Script;

    [Header("Police Choice Object Collection")]
    public GameObject OBJ_ChoiceObject;


    [Header("Particle Systems")]
    [SerializeField] ParticleSystem PS_Poof;

    string[] NPC_NodeChoices = new string[2];
    bool NPC_TriggerActive = false;
    bool NPC_InDialogue = false;

    private void Start()
    {
        
        UI_LineViewCanvas = UI_LineView.GetComponent<CanvasGroup>();
        UI_OptionsLineViewCanvas = UI_OptionsLineView.GetComponent<CanvasGroup>();
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            NPC_TriggerActive = true;
            MC_ReferenceScript.MC_InTrigger = true;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            NPC_TriggerActive = false;
            MC_ReferenceScript.MC_InTrigger = false;
        }
    }

    //Updates the volume of any attached auido when the settings are changed
    public void UpdateVolume(float newMasterVolume, float newMusicVolume, float newSFXVolume)
    {
        newMasterVolume = newMasterVolume / 100;
        newMusicVolume = newMusicVolume / 100;
        newSFXVolume = newSFXVolume / 100;

        AudioSource source = GetComponent<AudioSource>();
        float volume = newMasterVolume * newSFXVolume;
        source.volume = volume;
    }


    // Update is called once per frame
    void Update()
    {

        if (NPC_TriggerActive)
            NPC_Alert.SetActive(true);
        else
            NPC_Alert.SetActive(false);

        //Begins the interaction with the police if the player is in range
        if (Input.GetButtonDown("Interact") && NPC_TriggerActive && !NPC_InDialogue)
        {
            if (!MainMenuData.RunOnce)
                NPC_Runner.startNode = "Start_Police";
            else
                NPC_Runner.startNode = "Start_Police_2";

            //Checks to see if the start node exists
            if (NPC_Runner.NodeExists(NPC_Runner.startNode))
            {

                MC_ReferenceScript.PoliceTalk();
                NPC_PoliceAccusation_Script.Accuse();

                //Stops any running yarn file
                NPC_Runner.Stop();
                StartCoroutine(Hop());

                NPC_TextBox.transform.localScale = new Vector3(10, 10, 10);

                //Sets the UI to the policed
                SwitchSpeakerPol(false);

                MC_ReferenceScript.Talking(NPC_PlayerSocket.transform.position, true);
                MC_ReferenceScript.Jump(4);
                DIAG_InputRef.dialogueView = NPC_LineView;
                NPC_InDialogue = true;

                MC_ReferenceScript.CheckFlipMC();
                Cursor.lockState = CursorLockMode.None;
                Cursor.visible = true;

                NPC_Runner.StartDialogue(NPC_Runner.startNode);

                //Set UI images if they are valid

                if (UI_CharBG)
                {
                    UI_CharBGImage.enabled = true;
                    UI_CharBGImage.sprite = UI_CharBG;
                }
                else
                {
                    UI_CharBGImage.enabled = false;
                }

                if (UI_CharDetail)
                {
                    UI_CharDetailImage.enabled = true;
                    UI_CharDetailImage.sprite = UI_CharDetail;
                }
                else
                {
                    UI_CharDetailImage.enabled = false;
                }

                if (UI_CharDetail2)
                {
                    UI_CharDetailImage2.enabled = true;
                    UI_CharDetailImage2.sprite = UI_CharDetail;
                }
                else
                {
                    UI_CharDetailImage2.enabled = false;
                }

                if (UI_CharLine)
                {
                    UI_CharLineImage.enabled = true;
                    UI_CharLineImage2.enabled = true;
                    UI_CharLineImage.sprite = UI_CharLine;
                    UI_CharLineImage2.sprite = UI_CharLine;
                }
                else
                {
                    UI_CharLineImage.enabled = false;
                    UI_CharLineImage2.enabled = false;
                }

                if (UI_CharSprite)
                {
                    UI_CharSpriteImage.enabled = true;
                    UI_CharSpriteImage.sprite = UI_CharSprite;
                }
                else
                {
                    UI_CharSpriteImage.enabled = false;
                }

            }
        }


    }

    //Switchs the UI images to be either the police or the player character
    [YarnCommand("switch_speaker_pol")]
    public void SwitchSpeakerPol(bool playerSpeaking)
    {
        if (playerSpeaking)
        {
            DialogueViewBase[] newViews = new DialogueViewBase[3];
            newViews[0] = MC_LineView;
            newViews[1] = UI_LineView;
            newViews[2] = UI_OptionsLineView;


            NPC_Runner.dialogueViews = newViews;

            DIAG_InputRef.dialogueView = MC_LineView;

            MC_ReferenceScript.SetUI();

        }
        else
        {
            DialogueViewBase[] newViews = new DialogueViewBase[3];
            newViews[0] = NPC_LineView;
            newViews[1] = UI_LineView;
            newViews[2] = UI_OptionsLineView;


            NPC_Runner.dialogueViews = newViews;

            DIAG_InputRef.dialogueView = NPC_LineView;

            if (UI_CharBG)
            {
                UI_CharBGImage.enabled = true;
                UI_CharBGImage.sprite = UI_CharBG;
            }
            else
            {
                UI_CharBGImage.enabled = false;
            }

            if (UI_CharDetail)
            {
                UI_CharDetailImage.enabled = true;
                UI_CharDetailImage.sprite = UI_CharDetail;
            }
            else
            {
                UI_CharDetailImage.enabled = false;
            }

            if (UI_CharDetail2)
            {
                UI_CharDetailImage2.enabled = true;
                UI_CharDetailImage2.sprite = UI_CharDetail;
            }
            else
            {
                UI_CharDetailImage2.enabled = false;
            }

            if (UI_CharLine)
            {
                UI_CharLineImage.enabled = true;
                UI_CharLineImage2.enabled = true;
                UI_CharLineImage.sprite = UI_CharLine;
                UI_CharLineImage2.sprite = UI_CharLine;
            }
            else
            {
                UI_CharLineImage.enabled = false;
                UI_CharLineImage2.enabled = false;
            }

            if (UI_CharSprite)
            {
                UI_CharSpriteImage.enabled = true;
                UI_CharSpriteImage.sprite = UI_CharSprite;
            }
            else
            {
                UI_CharSpriteImage.enabled = false;
            }


        }
    }

    //Called when the max interactions are had to drop the police into the world
    public void DropIn()
    {


        int rand = Random.Range(0, 2);

        transform.localPosition.Set(NPC_SpawnLocations[rand].x, NPC_SpawnLocations[rand].y, NPC_SpawnLocations[rand].z);

        NPC_Clock.Play();

        StartCoroutine(DropInEnum());



    }

    //Scales the choice options for the player
    [YarnCommand("open_choices_pol")]
    public void OpenChoicesPol(bool open, string choice1, string choice2)
    {
        if (open)
        {
            MC_ChoiceTexts[0].text = choice2;
            MC_ChoiceTexts[1].text = choice1;
            MC_ChoiceOBJ.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
        }
        else
        {
            MC_ChoiceOBJ.transform.localScale = new Vector3(0, 0, 0);
            UI_OptionsLineViewCanvas.alpha = 0;
            UI_OptionsLineViewCanvas.blocksRaycasts = false;
            UI_OptionsLineViewCanvas.interactable = false;
        }
    }

    
    [YarnCommand("choice_options_pol")]
    public void ChoiceOptionsPol(string choice1, string choice2)
    {
        NPC_NodeChoices[0] = choice1;
        NPC_NodeChoices[1] = choice2;

    }

    //Resets the police and player after the conversation is over
    [YarnCommand("player_choice_pol")]
    public void PlayerChoicePol(bool index)
    {
        NPC_Runner.Stop();
        for (int i = 0; i < MC_ChoiceTexts.Length; i++)
        {
            MC_ChoiceTexts[i].text = "";
        }


        MC_Text.text = "";
        NPC_Text.text = "";
        MC_ChoiceOBJ.transform.localScale = new Vector3(0, 0, 0);
        UI_OptionsLineViewCanvas.alpha = 0;
        UI_OptionsLineViewCanvas.interactable = false;
        UI_OptionsLineViewCanvas.blocksRaycasts = false;
    }

    [YarnCommand("exit_speech_pol")]
    public void ExitSpeechPol()
    {

        MC_ReferenceScript.Exit();

        NPC_TextBox.transform.localScale = new Vector3(0, 0, 0);

        NPC_InDialogue = false;
    }

    [YarnCommand("open_choicesOBJ_pol")]
    public void OpenChoicesPol()
    {
        OBJ_ChoiceObject.transform.localScale = new Vector3(0.075f, 0.075f, 0.0075f);
    }

    [YarnCommand("play_audio_pol")]
    public void PlayAudioPol()
    {
        GetComponent<AudioSource>().PlayOneShot(NPC_Jingle);
    }

    [YarnCommand("hop_chime_pol")]
    public void HopChimePol()
    {
        StartCoroutine(Hop());
        GetComponent<AudioSource>().PlayOneShot(NPC_Jingle);
    }


    //Turns the police by a passed in amount
    [YarnCommand("turn_char_pol")]
    public void RotateNPCPol(int rotateAmountDeg)
    {

        StartCoroutine(Hop());
        StartCoroutine(Turn(rotateAmountDeg));

    }

    //Turns the police to face the player
    [YarnCommand("face_player_pol")]
    public void FacePlayerPol()
    {
        NPC_ModelRef.transform.eulerAngles = new Vector3(0, NPC_ModelRef.transform.eulerAngles.y + 10, 0);
    }

    //Resets the police rotation
    [YarnCommand("start_rot_pol")]
    public void StartRotPol()
    {
        NPC_ModelRef.transform.eulerAngles = new Vector3(0, 0, 0);
    }

    //IEnumerator to make the police hop up and down
    IEnumerator Hop()
    {
        float target = transform.position.y + 0.5f;
        Vector3 current = transform.position;
        float time = 0;

        while (time < 1)
        {
            NPC_ModelRef.transform.position = Vector3.Lerp(current, new Vector3(transform.position.x, target, transform.position.z), time);
            time += 0.1f;

            yield return new WaitForSeconds(0.00005f);

        }

        while (time > 0)
        {
            NPC_ModelRef.transform.position = Vector3.Lerp(current, new Vector3(transform.position.x, target, transform.position.z), time);
            time -= 0.1f;

            yield return new WaitForSeconds(0.00005f);

        }
    }

    //IEnumerator to make the police fall from the sky ---- Credit: Jack https://twitter.com/JackCL
    IEnumerator DropInEnum()
    {
        for (float i = 0; i < 1.9f; i += Time.deltaTime)
        {
            transform.DOMoveY(3.1f, 2.0f, false);
            yield return null;
        }
        PS_Poof.Play();
        yield return null;
    }

    //IEnumerator to make the police turn
    IEnumerator Turn(int rotation)
    {
        float target = NPC_ModelRef.transform.eulerAngles.y + rotation;
        Vector3 current = NPC_ModelRef.transform.eulerAngles;
        float time = 0;

        for (int i = 0; i < 11; i++)
        {
            NPC_ModelRef.transform.eulerAngles = Vector3.Lerp(current, new Vector3(transform.eulerAngles.x, target, transform.eulerAngles.z), time);
            time = time + 0.1f;

            yield return new WaitForSeconds(0.00005f);

        }


    }
}
