using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NPC_Spawn : MonoBehaviour
{
    [Header("NPC Ref Scripts")]
    public NPC_DialogueScript[] NPC_NPCScriptReferences;

    private int NPC_NumberOfGroups = 2; 

    // Start is called before the first frame update
    void Start()
    {


        int spawnGroupIndex;

        if (MainMenuData.RunOnce)
            spawnGroupIndex = 1;
        else
            spawnGroupIndex = 0;

        int spawnPosIndex = Random.Range(0, 2);


        //Chooses which group of NPC's to spawn and the index of their spawn location
        switch (spawnGroupIndex)
        {
            case 0:
                for(int i = 0; i < 4; i++)
                {
                    if(i < NPC_NPCScriptReferences.Length)
                    NPC_NPCScriptReferences[i].Spawn(spawnPosIndex);
                }
                break;
            case 1:
                for (int i = 4; i < 6; i++)
                {
                    if (i < NPC_NPCScriptReferences.Length)
                        NPC_NPCScriptReferences[i].Spawn(spawnPosIndex + 2);

                }
                for (int i = 6; i < 8; i++)
                {
                    if (i < NPC_NPCScriptReferences.Length)
                        NPC_NPCScriptReferences[i].Spawn(spawnPosIndex);

                }

                //Sets the talk state of various NPC's in the second loop
                NPC_NPCScriptReferences[4].SetTalkState(true);
                NPC_NPCScriptReferences[5].SetTalkState(false);
                NPC_NPCScriptReferences[6].SetTalkState(true);
                break;

            default:
                break;
        }
    }
}
