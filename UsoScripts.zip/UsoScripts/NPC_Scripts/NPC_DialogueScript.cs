using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Yarn.Unity;
using TMPro;
using DG.Tweening;

public class NPC_DialogueScript : MonoBehaviour
{

    public DialogueRunner NPC_Runner;
    [SerializeField] string NPC_StartNodeName;
    [SerializeField] DialogueAdvanceInput DIAG_InputRef;
    [SerializeField] MC_Controller MC_ReferenceScript;
    [SerializeField] GameObject NPC_PlayerSocket;
    [SerializeField] LineView NPC_LineView;
    [SerializeField] LineView MC_LineView;
    [SerializeField] LineView UI_LineView;
    CanvasGroup UI_LineViewCanvas;
    CanvasGroup UI_LineViewCanvasEXRTA;
    [SerializeField] OptionsListView UI_OptionsLineView;
    CanvasGroup UI_OptionsLineViewCanvas;
    [SerializeField] GameObject MC_ChoiceOBJ;
    [SerializeField] GameObject NPC_TextBox;
    [SerializeField] TMP_Text[] MC_ChoiceTexts;
    [SerializeField] TMP_Text MC_Text;
    [SerializeField] TMP_Text NPC_Text;
    [SerializeField] string NPC_Name;
    [SerializeField] GameObject[] UI_ClueRefs;
    [SerializeField] GameObject UI_Timer;
    [SerializeField] GameObject UI_Timer2;
    [SerializeField] Toggle UI_TextToggle;
    [SerializeField] int NPC_Index;
    [SerializeField] NPC_PoliceAccusation NPC_Police;
    [SerializeField] NPC_Idle NPC_IdleScript;

    [Header("UI Image References")]
    [SerializeField] Image UI_CharLineImage;
    [SerializeField] Image UI_CharLineImage2;
    [SerializeField] Image UI_CharBGImage;
    [SerializeField] Image UI_CharSpriteImage;
    [SerializeField] Image UI_CharDetailImage;
    [SerializeField] Image UI_CharDetailImage2;
    [SerializeField] GameObject UI_ClueIndicator;
    [SerializeField] GameObject UI_ClueBackground;

    [Header("UI Image Sprites")]
    [SerializeField] Sprite UI_CharLine;
    [SerializeField] Sprite UI_CharBG;
    [SerializeField] Sprite UI_CharSprite;
    [SerializeField] Sprite UI_CharDetail;
    [SerializeField] Sprite UI_CharDetail2;

    [Header("NPC Audio")]
    [SerializeField] AudioClip NPC_Jingle;
    [SerializeField] AudioSource AUD_Source;

    [Header("Emotes")]
    [SerializeField] GameObject NPC_Anger;
    [SerializeField] GameObject NPC_Brrr;
    [SerializeField] GameObject NPC_SweatR;
    [SerializeField] GameObject NPC_SweatB;
    [SerializeField] GameObject NPC_Stress;

    [Header("Model")]
    [SerializeField] GameObject NPC_ModelRef;
    [SerializeField] GameObject NPC_Alert;


    [Header("Spawn Locations")]
    [SerializeField] Vector3[] NPC_SpawnLocations;


    [Header("Main Char Refs")]
    [SerializeField] GameObject MC_TimerOBJ_1;
    [SerializeField] GameObject MC_TimerOBJ_2;

    [Header("State")]
    public bool NoTalk = false;
    bool DoneCheck = false;
    bool DoneCheck2 = false;
    int Index = 0;
    bool FirstTalk = false;

    string[] NPC_NodeChoices = new string[2];
    bool NPC_TriggerActive = false;
    bool NPC_InDialogue = false;
    bool NPC_TalkedTo = false;
    bool NPC_PoliceTalked = false;

    bool ChoiceOneConsume = false;
    bool ChoiceTwoConsume = false;



    private void Start()
    {
        UI_LineViewCanvas = UI_LineView.GetComponent<CanvasGroup>();
        UI_OptionsLineViewCanvas = UI_OptionsLineView.GetComponent<CanvasGroup>();
        UI_ClueIndicator.SetActive(false);
        UI_ClueBackground.SetActive(false);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player") && !NPC_TalkedTo)
        {
            NPC_TriggerActive = true;
            MC_ReferenceScript.MC_InTrigger = true;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            NPC_TriggerActive = false;
            MC_ReferenceScript.MC_InTrigger = false;
        }
    }


    // Update is called once per frame
    void Update()
    {
        

        if (NPC_TriggerActive)
            NPC_Alert.SetActive(true);
        else
            NPC_Alert.SetActive(false);

        //Begins the interaction with the NPC if the player is in range
        if (Input.GetButtonDown("Interact") && NPC_TriggerActive && !NPC_InDialogue && !NPC_TalkedTo)
        {
            if (NPC_Runner.NodeExists(NPC_StartNodeName))
            {
                NPC_Runner.Stop();
                StartCoroutine(Hop());

                NPC_IdleScript.StopIdle();

                NPC_TextBox.transform.localScale = new Vector3(10, 10, 10);
                MC_ReferenceScript.MC_CurrentNPC = this;

                SwitchSpeaker(false);

                MC_ReferenceScript.Talking(NPC_PlayerSocket.transform.position, true);
                MC_ReferenceScript.Jump(4);
                DIAG_InputRef.dialogueView = NPC_LineView;
                NPC_InDialogue = true;


                //Checks to see which node to run based off of the state of the NPC and the state of the POlice NPC
                if (MC_ReferenceScript.MC_OfficerArrived && !NPC_PoliceTalked)
                {
                    if (!MainMenuData.RunOnce)
                        NPC_Runner.startNode = "Police" + NPC_Name;
                    else
                    {
                        if (NPC_Runner.NodeExists("Police" + NPC_Name + "_2"))
                            NPC_Runner.startNode = "Police" + NPC_Name + "_2";
                        else
                            NPC_Runner.startNode = "Police" + NPC_Name;

                    }


                    NPC_PoliceTalked = true;
                }
                else if (NPC_PoliceTalked)
                {
                    NPC_Runner.startNode = "PostTalk2" + NPC_Name;
                }
                else
                {


                    if (FirstTalk && !DoneCheck)
                    {
                        NPC_Runner.startNode = "Choice" + Index.ToString() + NPC_Name;
                    }
                    else if (!NoTalk || DoneCheck)
                    {
                        if (!DoneCheck)
                            NPC_Runner.startNode = NPC_StartNodeName;
                        else if (DoneCheck && !DoneCheck2)
                            NPC_Runner.startNode = "PostTalk" + NPC_Name;
                        else if (DoneCheck && DoneCheck2)
                            NPC_Runner.startNode = "PostTalk2" + NPC_Name;
                    }
                    else if (NoTalk)
                        NPC_Runner.startNode = "NoTalk" + NPC_Name;
                }

                MC_ReferenceScript.CheckFlipMC();
                Cursor.lockState = CursorLockMode.None;
                Cursor.visible = true;

                //Runs the assigned start node
                NPC_Runner.StartDialogue(NPC_Runner.startNode);


                //Checks the NPC off as a possible choice for the player in the police
                NPC_Police.Checkoff(NPC_Index);
                if (!FirstTalk)
                    FirstTalk = true;


                //Set UI images if they are valid

                if (UI_CharBG)
                {
                    UI_CharBGImage.enabled = true;
                    UI_CharBGImage.sprite = UI_CharBG;
                }
                else
                {
                    UI_CharBGImage.enabled = false;
                }

                if (UI_CharDetail)
                {
                    UI_CharDetailImage.enabled = true;
                    UI_CharDetailImage.sprite = UI_CharDetail;
                }
                else
                {
                    UI_CharDetailImage.enabled = false;
                }

                if (UI_CharDetail2)
                {
                    UI_CharDetailImage2.enabled = true;
                    UI_CharDetailImage2.sprite = UI_CharDetail;
                }
                else
                {
                    UI_CharDetailImage2.enabled = false;
                }

                if (UI_CharLine)
                {
                    UI_CharLineImage.enabled = true;
                    UI_CharLineImage2.enabled = true;
                    UI_CharLineImage.sprite = UI_CharLine;
                    UI_CharLineImage2.sprite = UI_CharLine;
                }
                else
                {
                    UI_CharLineImage.enabled = false;
                    UI_CharLineImage2.enabled = false;
                }

                if (UI_CharSprite)
                {
                    UI_CharSpriteImage.enabled = true;
                    UI_CharSpriteImage.sprite = UI_CharSprite;
                }
                else
                {
                    UI_CharSpriteImage.enabled = false;
                }

            }
            else
            {
                Debug.LogErrorFormat("Error, unable to load start node: {0}", NPC_StartNodeName);
            }
        }

        if(NPC_Runner.IsDialogueRunning)
        {
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
        }

    }


    public void SetTalkState(bool state)
    {
        NoTalk = state;
    }

    //Sets which choices,if any, consume time
    [YarnCommand("set_consumption")]
    public void SetConsumption(bool one, bool two)
    {
        ChoiceOneConsume = one;
        ChoiceTwoConsume = two;
    }

    //Tweens the character emotes using DOTween
    [YarnCommand("tween_emote")]
    public void TweenEmote(int index)
    {
        switch (index)
        {
            case 0:
                NPC_Brrr.transform.DORestart();
                NPC_Brrr.transform.DOPlay();
                NPC_Anger.transform.DORestart();
                NPC_Anger.transform.DOPlay();
                NPC_SweatR.transform.DORestart();
                NPC_SweatR.transform.DOPlay();
                NPC_SweatB.transform.DORestart();
                NPC_SweatB.transform.DOPlay();
                NPC_Stress.transform.DORestart();
                NPC_Stress.transform.DOPlay();
                break;
            case 1:
                NPC_Brrr.transform.DOPunchScale(new Vector3(0.25f, 0.25f, 0.25f), 0.75f, 4, 0.4f);
                NPC_Anger.transform.DOPunchScale(new Vector3(0.25f, 0.25f, 0.25f), 0.75f, 4, 0.4f);
                NPC_SweatR.transform.DOPunchScale(new Vector3(0.25f, 0.25f, 0.25f), 0.75f, 4, 0.4f);
                NPC_SweatB.transform.DOPunchScale(new Vector3(0.25f, 0.25f, 0.25f), 0.75f, 4, 0.4f);
                NPC_Stress.transform.DOPunchScale(new Vector3(0.25f, 0.25f, 0.25f), 0.75f, 4, 0.4f);
                break;
            case 2:
                NPC_Anger.transform.DOLocalJump(new Vector3(0, 0.25f, 0), 0.1f, 2, 1);
                NPC_Brrr.transform.DOLocalJump(new Vector3(0, 0.25f, 0), 0.1f, 2, 1);
                NPC_SweatR.transform.DOLocalJump(new Vector3(0, 0.25f, 0), 0.1f, 2, 1);
                NPC_SweatB.transform.DOLocalJump(new Vector3(0, 0.25f, 0), 0.1f, 2, 1);
                NPC_Stress.transform.DOLocalJump(new Vector3(0, 0.25f, 0), 0.1f, 2, 1);
                break;
            default:
                break;
        }
    }

    //Tweens the character model using DOTween---- Credit: Jack https://twitter.com/JackCL
    [YarnCommand("tween_model")]
    public void TweenModel(int index)
    {
        switch (index)
        {
            case 0:
                NPC_ModelRef.transform.DORotate(new Vector3(NPC_ModelRef.transform.rotation.x, NPC_ModelRef.transform.rotation.y + 180, NPC_ModelRef.transform.rotation.z), 1);
                break;
            case 1:
                Vector3 startPos = NPC_ModelRef.transform.position;
                NPC_ModelRef.transform.DOJump(startPos, 1, 1, 0.5f);
                break;
            case 2:
                NPC_ModelRef.transform.DOShakePosition(1, 0.1f, 2);
                break;
            default:
                break;
        }

    }

    //Spawns the NPC
    public void Spawn(int index)
    {

        this.transform.position = NPC_SpawnLocations[index];
    }

    //Updates the volume of any attached auido when the settings are changed
    public void UpdateVolume(float newMasterVolume, float newMusicVolume, float newSFXVolume)
    {
        newMasterVolume = newMasterVolume / 100;
        newMusicVolume = newMusicVolume / 100;
        newSFXVolume = newSFXVolume / 100;

        AudioSource source = GetComponent<AudioSource>();
        float volume = newMasterVolume * newSFXVolume;
        source.volume = volume;
    }


    //Swaps the UI between the NPC and the player depending on who is talking
    [YarnCommand("switch_speaker")]
    public void SwitchSpeaker(bool playerSpeaking)
    {
        if (playerSpeaking)
        {
            DialogueViewBase[] newViews = new DialogueViewBase[3];
            newViews[0] = MC_LineView;
            newViews[1] = UI_LineView;
            newViews[2] = UI_OptionsLineView;


            NPC_Runner.dialogueViews = newViews;

            DIAG_InputRef.dialogueView = MC_LineView;

            MC_ReferenceScript.SetUI();

        }
        else
        {
            DialogueViewBase[] newViews = new DialogueViewBase[3];
            newViews[0] = NPC_LineView;
            newViews[1] = UI_LineView;
            newViews[2] = UI_OptionsLineView;


            NPC_Runner.dialogueViews = newViews;

            DIAG_InputRef.dialogueView = NPC_LineView;

            if (UI_CharBG)
            {
                UI_CharBGImage.enabled = true;
                UI_CharBGImage.sprite = UI_CharBG;
            }
            else
            {
                UI_CharBGImage.enabled = false;
            }

            if (UI_CharDetail)
            {
                UI_CharDetailImage.enabled = true;
                UI_CharDetailImage.sprite = UI_CharDetail;
            }
            else
            {
                UI_CharDetailImage.enabled = false;
            }

            if (UI_CharDetail2)
            {
                UI_CharDetailImage2.enabled = true;
                UI_CharDetailImage2.sprite = UI_CharDetail;
            }
            else
            {
                UI_CharDetailImage2.enabled = false;
            }

            if (UI_CharLine)
            {
                UI_CharLineImage.enabled = true;
                UI_CharLineImage2.enabled = true;
                UI_CharLineImage.sprite = UI_CharLine;
                UI_CharLineImage2.sprite = UI_CharLine;
            }
            else
            {
                UI_CharLineImage.enabled = false;
                UI_CharLineImage2.enabled = false;
            }

            if (UI_CharSprite)
            {
                UI_CharSpriteImage.enabled = true;
                UI_CharSpriteImage.sprite = UI_CharSprite;
            }
            else
            {
                UI_CharSpriteImage.enabled = false;
            }


        }
    }

    //Activates the butlers evidence page
    [YarnCommand("activate_butler")]
    public void ActivateButler()
    {
        MC_ReferenceScript.ActivateButler();
    }

    //---- Credit: Jack (CREDIT HOWEVER WANTED HERE)
    [YarnCommand("keep_going")]
    public void NPCKeepGoing()
    {
        MC_ReferenceScript.KeepGoing();
    }

    [YarnCommand("in_choice")]
    public void InChoice(bool value)
    {
        MC_ReferenceScript.ChoiceSet(value);
    }

    //Checks if the police NPC has spawned and ends dialogue if true
    [YarnCommand("check_police")]
    public void CheckPolice()
    {
        if (MC_ReferenceScript.MC_OfficerArrived)
        {
            NPC_Runner.Stop();
            ExitSpeech();
        }

    }

    //Open the in game dialogue choices and sets their text and the next yarn node they will path to to be the same text
    [YarnCommand("open_choices")]
    public void OpenChoices(bool open, string choice1, string choice2)
    {
        if (open)
        {
            MC_ChoiceTexts[0].text = choice1;
            MC_ChoiceTexts[1].text = choice2;

            NPC_NodeChoices[0] = choice1;
            NPC_NodeChoices[1] = choice2;
            MC_ChoiceOBJ.transform.localScale = new Vector3(210, 210, 210);
        }
        else
        {
            MC_ChoiceOBJ.transform.localScale = new Vector3(0, 0, 0);
            UI_OptionsLineViewCanvas.alpha = 0;
            UI_OptionsLineViewCanvas.blocksRaycasts = false;
            UI_OptionsLineViewCanvas.interactable = false;

        }
    }

    //Open the in game dialogue choices and sets their text and the next yarn node they will path to to be different text
    [YarnCommand("open_choices_text")]
    public void OpenChoicesText(bool open, string choice1, string choice2, string text1, string text2)
    {
        if (open)
        {
            MC_ChoiceTexts[0].text = text1;
            MC_ChoiceTexts[1].text = text2;

            NPC_NodeChoices[0] = choice1;
            NPC_NodeChoices[1] = choice2;
            MC_ChoiceOBJ.transform.localScale = new Vector3(210, 210, 210);
        }
        else
        {
            MC_ChoiceOBJ.transform.localScale = new Vector3(0, 0, 0);
            UI_OptionsLineViewCanvas.alpha = 0;
            UI_OptionsLineViewCanvas.blocksRaycasts = false;
            UI_OptionsLineViewCanvas.interactable = false;

        }
    }

    //Writes the choices the player has to the text boxes
    [YarnCommand("player_choice")]
    public void PlayerChoice(bool index)
    {
        NPC_Runner.Stop();
        MC_ChoiceOBJ.transform.localScale = new Vector3(0, 0, 0);
        UI_Timer.SetActive(false);
        UI_Timer2.SetActive(false);
        MC_TimerOBJ_1.SetActive(false);
        MC_TimerOBJ_2.SetActive(false);


        Debug.Log(ChoiceOneConsume.ToString());
        Debug.Log(ChoiceTwoConsume.ToString());

        if (index)
        {
            if (ChoiceTwoConsume)
                TickTimer();
            NPC_Runner.StartDialogue(NPC_NodeChoices[0] + NPC_Name);

        }
        else
        {
            if (ChoiceOneConsume)
                TickTimer();
            NPC_Runner.StartDialogue(NPC_NodeChoices[1] + NPC_Name);
        }
    }

    //Resets the player at the end of a conversation
    [YarnCommand("exit_speech")]
    public void ExitSpeech()
    {
        NPC_IdleScript.Restart();
        MC_ReferenceScript.Exit();

        NPC_TextBox.transform.localScale = new Vector3(0, 0, 0);

        NPC_InDialogue = false;
    }

    //Shows the timer icon to indicate time sonsumption in the UI and in game
    [YarnCommand("show_timer")]
    public void ShowTimer(bool show, int posInd)
    {

        if (!show)
        {
            UI_Timer.SetActive(show);
            UI_Timer2.SetActive(show);
            MC_TimerOBJ_1.SetActive(false);
            MC_TimerOBJ_2.SetActive(false);

            return;
        }

        
            if (posInd == 1)
            {
                ChoiceOneConsume = true;
                if (UI_TextToggle.isOn)
                    UI_Timer.SetActive(show);
                MC_TimerOBJ_1.SetActive(show);
            }

            if (posInd == 0)
            {
                ChoiceTwoConsume = true;
                if (UI_TextToggle.isOn)
                    UI_Timer2.SetActive(show);
                MC_TimerOBJ_2.SetActive(show);
            }
        

    }

    //Ticks the timer on the UI and changes the skybox accordingly
    [YarnCommand("tick_timer")]
    public void TickTimer()
    {
        ChoiceOneConsume = false;
        ChoiceTwoConsume = false;
        MC_ReferenceScript.YarnChoice();
    }

    //if the player triggers a clue, activate it and tween it on screen ---- Credit: Jack https://twitter.com/JackCL
    [YarnCommand("found_clue")]
    public void FoundClue(int clueIndex)
    {
        UI_ClueRefs[clueIndex].SetActive(true);
        if (!UI_ClueIndicator.activeSelf)
        {
            UI_ClueIndicator.SetActive(true);
            UI_ClueBackground.SetActive(true);
            DOTween.Restart("ClueIn");
            DOTween.PlayForward("ClueIn");
        }
    }

    [YarnCommand("play_audio")]
    public void PlayAudio()
    {
        GetComponent<AudioSource>().PlayOneShot(NPC_Jingle);
    }

    [YarnCommand("hop_chime")]
    public void HopChime()
    {
        NPC_ModelRef.transform.DOJump(new Vector3(), 1, 1, 1);
        GetComponent<AudioSource>().PlayOneShot(NPC_Jingle);
    }

    //Spawns/despawn an emotion on the NPC based on the passed index ---- Credit: Jack https://twitter.com/JackCL
    [YarnCommand("spawn_emotion")]
    public void SpawnEmotion(int emotionIndex, bool show)
    {
        if (!show)
        {
            NPC_Anger.SetActive(false);
            NPC_Brrr.SetActive(false);
            NPC_SweatR.SetActive(false);
            NPC_SweatB.SetActive(false);
            NPC_Stress.SetActive(false);
            return;
        }

        switch (emotionIndex)
        {
            case 0:
                NPC_Anger.SetActive(true);
                DOTween.Restart("Anger");
                DOTween.Play("Anger");
                break;
            case 1:
                NPC_Brrr.SetActive(true);
                DOTween.Restart("Brrr");
                DOTween.Play("Brrr");
                break;
            case 2:
                NPC_SweatR.SetActive(true);
                DOTween.Restart("RedS");
                DOTween.Play("RedS");
                break;
            case 3:
                NPC_SweatB.SetActive(true);
                DOTween.Restart("BlueS");
                DOTween.Play("BlueS");
                break;
            case 4:
                NPC_Stress.SetActive(true);
                DOTween.Restart("StressP");
                DOTween.Play("StressP");
                break;


            default:
                break;
        }
    }

    //Turns the NPC by a passed in amount
    [YarnCommand("turn_char")]
    public void RotateNPC(int rotateAmountDeg)
    {

        StartCoroutine(Hop());
        StartCoroutine(Turn(rotateAmountDeg));

    }

    //Turns the NPC to face the player
    [YarnCommand("face_player")]
    public void FacePlayer(bool large)
    {



        if (large)
            NPC_ModelRef.transform.DORotate(new Vector3(0, 200, 0), 0.5f);

        if (!large)
            NPC_ModelRef.transform.DORotate(new Vector3(0, 20, 0), 0.5f);
    }

    //Resets the NPC rotation
    [YarnCommand("start_rot")]
    public void StartRot()
    {
        NPC_ModelRef.transform.eulerAngles = new Vector3(0, 0, 0);
    }

    //IEnumerator to make the NPC hop up and down
    IEnumerator Hop()
    {
        float target = transform.position.y + 0.5f;
        Vector3 current = transform.position;
        float time = 0;

        while (time < 1)
        {
            NPC_ModelRef.transform.position = Vector3.Lerp(current, new Vector3(transform.position.x, target, transform.position.z), time);
            time += 0.1f;

            yield return new WaitForSeconds(0.00005f);

        }

        while (time > 0)
        {
            NPC_ModelRef.transform.position = Vector3.Lerp(current, new Vector3(transform.position.x, target, transform.position.z), time);
            time -= 0.1f;

            yield return new WaitForSeconds(0.00005f);

        }
    }

    //Misc state checks for yarnspinner
    [YarnCommand("done")]
    public void Done()
    {
        DoneCheck = true;
    }

    [YarnCommand("done2")]
    public void Done2()
    {
        DoneCheck2 = true;
    }

    [YarnCommand("set_index")]
    public void SetIndex(int num)
    {
        Index = num;
    }

    //IEnumerator to make the NPC turn
    IEnumerator Turn(int rotation)
    {
        float target = NPC_ModelRef.transform.eulerAngles.y + rotation;
        Vector3 current = NPC_ModelRef.transform.eulerAngles;
        float time = 0;

        for (int i = 0; i < 11; i++)
        {
            NPC_ModelRef.transform.eulerAngles = Vector3.Lerp(current, new Vector3(transform.eulerAngles.x, target, transform.eulerAngles.z), time);
            time = time + 0.1f;

            yield return new WaitForSeconds(0.00005f);

        }


    }
}
