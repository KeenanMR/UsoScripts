using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using System.Collections;



public class UI_MainMenu : MonoBehaviour
{
    [SerializeField] GameObject MenuReference;
    [SerializeField] GameObject LoadingReference;
    [SerializeField] GameObject SecondMenuReference;
    [SerializeField] GameObject AgainButton;
    public Slider[] LoadingBars;

    public GameObject[] LoadingOptions;
    public AudioClip LoadingClip;

    bool IsLoading = false;
    bool firstTime = true;
    bool canPlayAgain = false;

    [SerializeField] AudioClip UI_MenuSwapMusic;

    private void Awake()
    {
        //---- Credit: Jack https://twitter.com/JackCL
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;

        //If the game has already been run, update the menu accordingly with new audio and UI //---- Credit: Michael
        if (MainMenuData.RunOnce)
        {
            SecondMenuReference.SetActive(true);
            MenuReference.SetActive(false);
            EventSystem.current.SetSelectedGameObject(AgainButton);
            Debug.Log("selected object: " + EventSystem.current.currentSelectedGameObject.name);
            AudioSource audio = this.GetComponent<AudioSource>();
            audio.clip = UI_MenuSwapMusic;
            audio.Play();
        }
        canPlayAgain = false;
    }

    private void Start()
    {
        StartCoroutine(StartButtonDelay());
    }
    //---- Credit: Jack https://twitter.com/JackCL
    IEnumerator StartButtonDelay() 
    {
        for (float i = 0; i < 0.5f; i+= Time.deltaTime)
        {
            yield return null;
        }
        canPlayAgain = true;
    }

    public void OnPlayClick()
    {
        if (!canPlayAgain)
        {
            return;
        }

        //When play is clicked, hide the menu UI and load a random character loading screen.
        SecondMenuReference.SetActive(false);
        MenuReference.SetActive(false);
        
        LoadingReference.SetActive(true);
        
        int randNum = Random.Range(0, 5);
        LoadingOptions[randNum].SetActive(true);

        StartCoroutine(WaitLoad());
        StartCoroutine(FakeBar());

        AudioSource audio = this.GetComponent<AudioSource>();
        audio.PlayOneShot(LoadingClip);
    }

    private void Update()
    {
        if (IsLoading)
        {

            StopAllCoroutines();

            SceneManager.LoadScene("OutdoorScene");
        }

    }

    public void OnQuitClick()
    {
        Application.Quit();
    }

    //Fills up the loading bar over time
    IEnumerator FakeBar()
    {
        Slider currentBar;

        for (int i = 0; i < LoadingBars.Length; i++)
        {
            if (LoadingBars[i].IsActive())
            {
                currentBar = LoadingBars[i];

                for (int j = 0; j < 500; j++)
                {
                    yield return new WaitForSecondsRealtime(0.003f);
                    currentBar.value = j;

                }
                break;
            }
        }

     

        yield return null;
    }

    IEnumerator WaitLoad()
    {

        yield return new WaitForSecondsRealtime(5);


        IsLoading = true;
    }
}
