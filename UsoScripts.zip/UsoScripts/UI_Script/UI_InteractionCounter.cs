using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;

public class UI_InteractionCounter : MonoBehaviour
{
    public GameObject TimerArrow;
    public Light UI_SceneLight;
    public MC_Controller MC_PlayerRef;
    public GameObject UI_ClueIcon;

    [SerializeField] Transform light;
    [SerializeField] Material skybox = null;
    [SerializeField] Gradient skyColour;
    [SerializeField] Gradient fogColour;
    float interactionMax;
    float currentRot = 0;

    /*
        Colours:
     
        Darkest - F:6A5A51      S: 322835
        light   - F:D6B8A7      S: 686372
        Middle  - F:8E7060      S: 251F3D
        Morning - F:AE946C      S: F1BEBE
     
     
     */

    //---- Credit: Jack https://twitter.com/JackCL
    private void Start()
    {
        interactionMax = MC_PlayerRef.MC_InteractionMax;

        RenderSettings.skybox = new Material(RenderSettings.skybox);
    }

    //---- Credit: Jack https://twitter.com/JackCL
    public void AdvanceTime()
    {
        //move UI arrow
        TimerArrow.transform.DOLocalRotate(new Vector3(0, 0, currentRot - (180 / interactionMax)), 2);
        currentRot = currentRot - (180 / interactionMax);

        float currentInteraction = MC_PlayerRef.MC_InteractionCount;

        //move light and shadows
        light.DORotate(new Vector3(light.rotation.eulerAngles.x, light.rotation.eulerAngles.y + 2, light.rotation.eulerAngles.z), 2.0f);
        


        //get gradient by taking fraction of day completeness, add 1 of those fractions to make day start after 0 and finish at 1
        Vector4 newSkyColour = skyColour.Evaluate((currentInteraction / interactionMax) + 1 / interactionMax);
        RenderSettings.skybox.DOVector(newSkyColour, "_TintColor", 2.0f);
        Color newFogColour = fogColour.Evaluate((currentInteraction / interactionMax) + 1 / interactionMax);
        StopAllCoroutines();
        StartCoroutine(BlendFog(RenderSettings.fogColor, newFogColour));
    }

    //---- Credit: Jack https://twitter.com/JackCL
    IEnumerator BlendFog(Color oldFogColour, Color newFogColour)
    {
        Vector4 newColour = new Color();
        float t = 0;

        //lerp between colours
        for (float i = 0; i < 2.0f; i += Time.deltaTime)
        {
            t += Time.deltaTime / 2;
            if (t > 1)
                t = 1;
            newColour = Color.Lerp(oldFogColour, newColour, t);
            RenderSettings.fogColor = newColour;
            yield return null;
        }
    }
}
