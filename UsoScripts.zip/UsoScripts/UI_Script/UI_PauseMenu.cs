using UnityEngine;
using TMPro;
using UnityEngine.Rendering;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using DG.Tweening;
using UnityEngine.Audio;
using Yarn.Unity;

public class UI_PauseMenu : MonoBehaviour, IPointerEnterHandler
{

    public GameObject UI_Settings;
    public GameObject UI_Volume;
    public GameObject UI_PauseMenuReference;
    public GameObject UI_CharacterPages;
    public GameObject UI_ButlerPage;

    public List<GameObject> UI_CharacterPageList;
    int butlerUnlockNum = 1;

    public TMP_Dropdown UI_Grpahics;
    public RenderPipelineAsset[] UI_QualityLevels;

    public int UI_CharacterPagesIndex = 0;

    public NPC_DialogueScript[] NPCs;
    public MC_Controller MC;
    [SerializeField] NPC_PoliceScript Popo;

    [SerializeField] GameObject UI_PauseMenuFirst, UI_SettingsMenuFirst, UI_AudioMenuFirst;
    [SerializeField] GameObject[] UI_PageStarterButtons;

    [SerializeField] Slider MasterSlider;
    [SerializeField] Slider MusicSlider;
    [SerializeField] Slider SFXSlider;

    [SerializeField] TMP_Text MasterTXT;
    [SerializeField] TMP_Text MusicTXT;
    [SerializeField] TMP_Text SFXTXT;


    [SerializeField] GameObject TIcon;
    [SerializeField] TMP_Text[] AccessTexts;
    [SerializeField] TMP_Dropdown UI_FontSize;
    [SerializeField] GameObject UI_OptionsTextCollection;

    float MasterVol = 50.0f;
    float MusicVol = 50.0f;
    float SFXVol = 10.0f;

    [SerializeField] AudioMixer audioMixer = null;

    private void Start()
    {
        butlerUnlockNum = 1;
    }

    //Detect if the Cursor starts to pass over the GameObject
    public void OnPointerEnter(PointerEventData pointerEventData)
    {
        EventSystem.current.SetSelectedGameObject(null);
    }

    //If the player is in the evidence book, cycle through the pages with key inputs //---- Credit: Jack https://twitter.com/JackCL
    private void Update()
    {
        if (UI_CharacterPages.activeSelf)
        {
            if (Input.GetKeyDown(KeyCode.D) || Input.GetKeyDown(KeyCode.RightArrow))
            {
                OnRightArrowClick();
            }
            if (Input.GetKeyDown(KeyCode.A) || Input.GetKeyDown(KeyCode.LeftArrow))
            {
                OnLeftArrowClick();
            }
        }
    }

    public void ActivateButler()
    {
        butlerUnlockNum = 0;
    }

    //---- Credit: Jack https://twitter.com/JackCL
    public void StartPause()
    {
        EventSystem.current.SetSelectedGameObject(null);
        EventSystem.current.SetSelectedGameObject(UI_PauseMenuFirst);

        DOTween.Restart("HideT");
        DOTween.PlayForward("HideT");


    }
    //---- Credit: Jack https://twitter.com/JackCL
    public void EndPause()
    {
        EventSystem.current.SetSelectedGameObject(null);

        DOTween.Complete("HideT");
        DOTween.PlayBackwards("HideT");

        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }

    public void OnResumeClick()
    {
        EventSystem.current.SetSelectedGameObject(null);
        Time.timeScale = 1;
        gameObject.SetActive(false);
        MC.MC_Paused = false;

        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;

        if (UI_CharacterPages.activeSelf)
        {
            UI_CharacterPages.SetActive(false);
        }

        if (UI_Volume.activeSelf)
        {
            UI_Volume.SetActive(false);
        }

        if (UI_Settings.activeSelf)
        {
            UI_Settings.SetActive(false);
        }

        //---- Credit: Jack https://twitter.com/JackCL
        DOTween.Complete("HideT");
        DOTween.PlayBackwards("HideT");
    }

    public void OnQuitClick()
    {
        SceneManager.LoadScene("mainmenu");

        //---- Credit: Jack https://twitter.com/JackCL
        Time.timeScale = 1;
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
    }

    public void OnSettingsClick()
    {

        if (UI_Settings.activeSelf)
        {

            EventSystem.current.SetSelectedGameObject(null);
            EventSystem.current.SetSelectedGameObject(UI_PauseMenuFirst);
            UI_Volume.SetActive(false);
            UI_Settings.SetActive(false);
            return;
        }


        if (!UI_Settings.activeSelf)
        {
            EventSystem.current.SetSelectedGameObject(null);
            EventSystem.current.SetSelectedGameObject(UI_SettingsMenuFirst);
            UI_Volume.SetActive(false);
            UI_Settings.SetActive(true);

        }
    }

    public void OnVolumeClick()
    {
        if (!UI_Volume.activeSelf)
        {
            EventSystem.current.SetSelectedGameObject(null);
            EventSystem.current.SetSelectedGameObject(UI_AudioMenuFirst);
            UI_Settings.SetActive(false);


            UI_Volume.SetActive(true);
        }
    }
    //Update master volume //---- Credit: Jack https://twitter.com/JackCL
    public void MasterVolume()
    {
        audioMixer.SetFloat("MasterVolume", Mathf.Log10(MasterSlider.value) * 20);
        float value = MasterSlider.value * 50;
        MasterTXT.text = ((int)value).ToString();
    }

    //Update music volume //---- Credit: Jack https://twitter.com/JackCL
    public void MusicVolume()
    {
        audioMixer.SetFloat("MusicVolume", Mathf.Log10(MusicSlider.value) * 20);
        float value = MusicSlider.value * 50;
        MusicTXT.text = ((int)value).ToString();
    }

    //Update sfx volume //---- Credit: Jack https://twitter.com/JackCL
    public void SFXVolume()
    {
        audioMixer.SetFloat("SFXVolume", Mathf.Log10(SFXSlider.value) * 20);
        float value = SFXSlider.value * 50;
        SFXTXT.text = ((int)value).ToString();
    }

    //Button click function that activates and deactivates UI elements depending on the button pressed
    public void OnHomeClick(bool pause)
    {
        if (UI_CharacterPages.activeSelf)
        {

            UI_CharacterPages.SetActive(false);
        }

        if (UI_Volume.activeSelf)
        {

            UI_Volume.SetActive(false);
        }

        if (UI_Settings.activeSelf)
        {

            UI_Settings.SetActive(false);
        }

        if (!UI_PauseMenuReference.activeSelf)
        {
            StartPause();
            UI_PauseMenuReference.SetActive(true);
        }

        //---- Credit: Jack https://twitter.com/JackCL
        if (!pause)
        {
            gameObject.SetActive(false);
            Time.timeScale = 1;
            UI_PauseMenuReference.SetActive(false);
            MC.MC_Paused = false;
            DOTween.Complete("HideT");
            DOTween.PlayBackwards("HideT");
        }
    }

    //Button click function that activates and deactivates UI elements depending on the button pressed
    public void OnGearClick()
    {
        if (UI_CharacterPages.activeSelf)
        {

            UI_CharacterPages.SetActive(false);
        }

        if (UI_Volume.activeSelf)
        {

            UI_Volume.SetActive(false);
        }

        if (!UI_Settings.activeSelf)
        {
            EventSystem.current.SetSelectedGameObject(null);
            EventSystem.current.SetSelectedGameObject(UI_SettingsMenuFirst);

            UI_Settings.SetActive(true);
        }

        if (!UI_PauseMenuReference.activeSelf)
        {

            UI_PauseMenuReference.SetActive(true);
        }
    }

    //Button click function that activates and deactivates UI elements depending on the button pressed
    public void OnEvidenceClick()
    {

        if (!UI_CharacterPages.activeSelf)
        {

            UI_CharacterPages.SetActive(true);
        }

        if (UI_Volume.activeSelf)
        {

            UI_Volume.SetActive(false);
        }

        if (UI_Settings.activeSelf)
        {

            UI_Settings.SetActive(false);
        }

        if (UI_PauseMenuReference.activeSelf)
        {

            UI_PauseMenuReference.SetActive(false);
        }

        if (!UI_CharacterPages.activeSelf)
        {

            UI_CharacterPageList[UI_CharacterPagesIndex].SetActive(true);

        }


        EventSystem.current.SetSelectedGameObject(null);
        EventSystem.current.SetSelectedGameObject(UI_PageStarterButtons[UI_CharacterPagesIndex]);
    }

    //When the arrow is clicked, update the selected game object and move to the next character page
    //If the page is the last page in the array, go to the other end of the array //---- Credit: Jack https://twitter.com/JackCL
    public void OnLeftArrowClick()
    {
        if (UI_CharacterPagesIndex != 0)
        {
            UI_CharacterPageList[UI_CharacterPagesIndex].SetActive(false);
            UI_CharacterPagesIndex--;
            EventSystem.current.SetSelectedGameObject(null);
            EventSystem.current.SetSelectedGameObject(UI_PageStarterButtons[UI_CharacterPagesIndex]);

            UI_CharacterPageList[UI_CharacterPagesIndex].SetActive(true);

        }
        else
        {
            UI_CharacterPageList[UI_CharacterPagesIndex].SetActive(false);
            UI_CharacterPagesIndex = UI_CharacterPageList.Count - 1 - butlerUnlockNum;
            EventSystem.current.SetSelectedGameObject(null);
            EventSystem.current.SetSelectedGameObject(UI_PageStarterButtons[UI_CharacterPagesIndex]);
            UI_CharacterPageList[UI_CharacterPagesIndex].SetActive(true);
        }
    }

    //When the arrow is clicked, update the selected game object and move to the next character page
    //If the page is the last page in the array, go to the other end of the array //---- Credit: Jack https://twitter.com/JackCL
    public void OnRightArrowClick()
    {
        if (UI_CharacterPagesIndex != UI_CharacterPageList.Count - 1 - butlerUnlockNum)
        {
            UI_CharacterPageList[UI_CharacterPagesIndex].SetActive(false);
            UI_CharacterPagesIndex++;
            EventSystem.current.SetSelectedGameObject(null);
            EventSystem.current.SetSelectedGameObject(UI_PageStarterButtons[UI_CharacterPagesIndex]);
            UI_CharacterPageList[UI_CharacterPagesIndex].SetActive(true);
        }
        else 
        {
            UI_CharacterPageList[UI_CharacterPagesIndex].SetActive(false);
            UI_CharacterPagesIndex = 0;
            EventSystem.current.SetSelectedGameObject(null);
            EventSystem.current.SetSelectedGameObject(UI_PageStarterButtons[UI_CharacterPagesIndex]);
            UI_CharacterPageList[UI_CharacterPagesIndex].SetActive(true);
        }
    }

    //Update the graphics settings
    public void OnGraphicsSettingUpdate()
    {
        QualitySettings.SetQualityLevel(UI_Grpahics.value);
        QualitySettings.renderPipeline = UI_QualityLevels[UI_Grpahics.value];
    }

    //Updates the font size of all UI elements
    public void OnFontSizeUpdate()
    {
        switch (UI_FontSize.value)
        {
            case 3:

                for(int i = 0; i < AccessTexts.Length; i++)
                {
                    AccessTexts[i].fontSize = 18;
                }

                OptionView[] options = UI_OptionsTextCollection.GetComponentsInChildren<OptionView>();

                for (int i = 0; i < options.Length; i++)
                {
                    options[i].GetComponent<TMP_Text>().fontSize = 18;
                }

                break;

            case 0:

                for (int i = 0; i < AccessTexts.Length; i++)
                {
                    AccessTexts[i].fontSize = 36;
                }

                OptionView[] options2 = UI_OptionsTextCollection.GetComponentsInChildren<OptionView>();

                for (int i = 0; i < options2.Length; i++)
                {
                    options2[i].GetComponent<TMP_Text>().fontSize = 36;
                }

                break;

            case 1:

                for (int i = 0; i < AccessTexts.Length; i++)
                {
                    AccessTexts[i].fontSize = 54;
                }

                OptionView[] options3 = UI_OptionsTextCollection.GetComponentsInChildren<OptionView>();

                for (int i = 0; i < options3.Length; i++)
                {
                    options3[i].GetComponent<TMP_Text>().fontSize = 54;
                }

                break;

            default:
                break;
        }
    }
}
