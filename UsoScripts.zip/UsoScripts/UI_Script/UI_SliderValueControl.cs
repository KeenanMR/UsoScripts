using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using TMPro;

public class UI_SliderValueControl : MonoBehaviour
{
    public TMP_Text UI_TextReference;

    //Updates the menu text when the slider is updated
   public void OnSliderValueChange()
    {
        float value = this.GetComponent<Slider>().value;

        UI_TextReference.SetText(value.ToString() );
    }

}
