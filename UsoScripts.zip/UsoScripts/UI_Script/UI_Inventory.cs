using System.Collections;

using UnityEngine;

public class UI_Inventory : MonoBehaviour
{
    /// <summary>
    /// Legacy code from when an inventory system was planned
    /// </summary>



    //Array of Raw Image Game Objects
    public GameObject[] UI_ClueImages;
    public GameObject UI_ClueTarget;
    

    //Parameter variables
    float UI_ClueSpeed = 1000;
    bool UI_Zoomed = false;

    Vector3 UI_ClueImage_InitialPositions = new Vector3();

    public void UnlockClue(int UI_ClueNumber)
    {
        UI_ClueImages[UI_ClueNumber].SetActive(true);
    }

    //Zooms into the render texture image of the found clue for further inspection
    public void OnClueClick(int UI_ClueNumber)
    {
        if (!UI_Zoomed)
        {
            UI_Zoomed = true;
            UI_ClueImage_InitialPositions = UI_ClueImages[UI_ClueNumber].transform.position;
            StartCoroutine(ScaleZoom(UI_ClueNumber));
            return;
        }

        if (UI_Zoomed)
        {
            UI_Zoomed = false;
            StartCoroutine(UnScaleZoom(UI_ClueNumber));
            return;
        }

    }

    //IENumerator to zoom in
    IEnumerator ScaleZoom(int UI_ClueNumber)
    {

        var step = UI_ClueSpeed * Time.unscaledDeltaTime;


        while (UI_ClueImages[UI_ClueNumber].transform.position != UI_ClueTarget.transform.position)
        {
            UI_ClueImages[UI_ClueNumber].transform.position = Vector3.MoveTowards(UI_ClueImages[UI_ClueNumber].transform.position, UI_ClueTarget.transform.position, step);
            UI_ClueImages[UI_ClueNumber].transform.localScale = new Vector3(UI_ClueImages[UI_ClueNumber].transform.localScale.x + step/300, UI_ClueImages[UI_ClueNumber].transform.localScale.y + step/300, UI_ClueImages[UI_ClueNumber].transform.localScale.z);
            yield return new WaitForSecondsRealtime(0.001f);
        }
    }
    //IENumerator to zoom out
    IEnumerator UnScaleZoom(int UI_ClueNumber)
    {

        var step = UI_ClueSpeed * Time.unscaledDeltaTime;


        while (UI_ClueImages[UI_ClueNumber].transform.position != UI_ClueImage_InitialPositions)
        {
            UI_ClueImages[UI_ClueNumber].transform.position = Vector3.MoveTowards(UI_ClueImages[UI_ClueNumber].transform.position, UI_ClueImage_InitialPositions, step);
            UI_ClueImages[UI_ClueNumber].transform.localScale = new Vector3(UI_ClueImages[UI_ClueNumber].transform.localScale.x - step / 300, UI_ClueImages[UI_ClueNumber].transform.localScale.y - step / 300, UI_ClueImages[UI_ClueNumber].transform.localScale.z);
            yield return new WaitForSecondsRealtime(0.001f);
        }
    }
}
