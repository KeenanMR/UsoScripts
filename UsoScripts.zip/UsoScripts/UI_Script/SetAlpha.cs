using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SetAlpha : MonoBehaviour
{
    [SerializeField] CanvasGroup canvasGroup;



    public void Alpha(float alpha)
    {
        canvasGroup.alpha = alpha;
    }

    public void Alpha(Slider alpha)
    {

        float value = alpha.value / 100;

        canvasGroup.alpha = 1- value;
    }
}
