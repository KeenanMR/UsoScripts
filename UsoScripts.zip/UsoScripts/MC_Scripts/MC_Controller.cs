using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using Yarn.Unity;
using DG.Tweening;
using Cinemachine;

public class MC_Controller : MonoBehaviour
{
    [SerializeField] DOTweenAnimation flipAnim = null;
    [SerializeField] Transform model = null;
    bool flip = true;
    float walkTimer = 0.0f;
    private CharacterController controller;
    private Vector3 playerVelocity;
    private bool groundedPlayer;
    private float playerSpeed = 7f;
    private float jumpHeight = 1.0f;
    private float gravityValue = -9.81f;
    [SerializeField] Vector3 secondStartPos = Vector3.zero;
    [SerializeField] CinemachineFreeLook mainCam = null;
    [SerializeField] GameObject UI_ClueImageRef;
    [SerializeField] GameObject UI_ClueBackground;
    [SerializeField] DIAG_PlayerChoice[] ChoiceScripts; 



    //Player Data
    public bool MC_InTrigger = false;
    bool MC_Spawning = true;
    public bool MC_Talking = false;
    public bool MC_MakingChoice = false;
    bool MC_Police = false;
    public int MC_InteractionCount = 0;
    public int MC_InteractionMax = 1;
    int MC_ChoiceIndex = 0;
    public bool MC_OfficerArrived = false;

    //Player clue data
    public bool[,] MC_ClueIndex;

    //Police Ref
    [Header("Police Reference Data")]
    public GameObject MC_PoliceRef;

    //Player Child Data
    public GameObject MC_AlertSprite;

    [Header("TextBox Mesh Data")]
    public GameObject MC_TextBoxMesh;
    public GameObject MC_ChoiceMeshGroup;
    public TMP_Text MC_TextBoxText;
    public TMP_Text[] MC_ChoiceText = new TMP_Text[2];
    public TMP_Text MC_OnScreemText;

    [Header("OnScreenText Images")]
    public Image UI_Image;
    public Image UI_Image_Background;
    public Image UI_Image_Detail_1;
    public Image UI_Image_Detail_2;
    public Image UI_Image_Frame;

    //NPC Information
    [Header("Sprite Data")]
    public Sprite MC_Sprite_Background;
    public Sprite MC_Sprite_Detail_1;
    public Sprite MC_Sprite_Detail_2;
    public Sprite MC_Sprite;
    public Sprite MC_Sprite_Frame;

    //Text Data
    private string[] MC_TextData;
    private string MC_ChosenText;
    private string[,] MC_ChoiceDataArray;
    bool MC_TextBoxMesh_Scaled = false;
    [SerializeField] Toggle UI_TextToggle;

    //UI References
    [Header("UI Refs")]
    public GameObject UI_PauseMenu;
    public UI_PauseMenu UI_PauseMenuScript;
    public UI_InteractionCounter UI_CounterRef;

    public NPC_DialogueScript MC_CurrentNPC;

    [SerializeField] ParticleSystem MC_Poof;
    [SerializeField] ParticleSystem MC_SmallPoof;

    bool MC_SmallPoofCheck = true;
    bool MC_FirstGround = false;
    bool MC_InChoice = false;
    public bool MC_Paused = false;
    [SerializeField] float MC_DistToGround = 0;
    float MC_Falltime = 0;

    //Yarn
    [SerializeField] DialogueRunner NPC_Runner;
    [SerializeField] GameObject UI_Group;
    [SerializeField] GameObject UI_OptionsGroup;
    [SerializeField] CanvasGroup UI_ClueBookGroup;

    bool superSpeed = false;

    private void Start()
    {

        //Player character controller default values
        controller = gameObject.AddComponent<CharacterController>();
        controller.radius = 4.0f;
        controller.slopeLimit = 90.0f;
        controller.stepOffset = 1.0f;
        controller.height = 18.0f;

        //get the height of the player character
        MC_DistToGround = GetComponent<MeshCollider>().bounds.extents.y;


        if (MainMenuData.RunOnce)
        {
            GetComponent<CharacterController>().enabled = false;
            mainCam.OnTargetObjectWarped(transform, secondStartPos - transform.position);
            transform.position = secondStartPos;
            GetComponent<CharacterController>().enabled = true;
        }
    }

    void Update()
    {

        if (Grounded() && MC_FirstGround && !MC_SmallPoofCheck)
        {

            MC_SmallPoof.Play();
            MC_SmallPoofCheck = true;
            //bounce anim ---- Credit: Jack (CREDIT HOWEVER WANTED HERE)
            model.DOPunchScale(new Vector3(0, -0.1f, 0), 0.3f, 1, 0);
            model.DOPunchPosition(new Vector3(0, -0.1f, 0), 0.3f, 1, 0);
        }

        //Check how long the player is in the air before resetting the timer to play PS
        if (!Grounded())
        {
            MC_Falltime += Time.deltaTime;

            if (MC_Falltime > 0.5f)
            {
                MC_Falltime = 0;
                MC_SmallPoofCheck = false;
            }
        }

        groundedPlayer = controller.isGrounded;


        //Check if the player hits the ground for the first time triggering startup
        if (groundedPlayer)
        {
            if (!MC_FirstGround)
            {
                MC_FirstGround = true;
                Jump(1);
                StartCoroutine(StarterSpeech());
                MC_Poof.Play();

                //bounce anim ---- Credit: Jack (CREDIT HOWEVER WANTED HERE)
                model.DOPunchScale(new Vector3(0, -0.3f, 0), 0.5f, 1, 0);
                model.DOPunchPosition(new Vector3(0, -0.3f, 0), 0.5f, 1, 0);
            }
        }

        if (groundedPlayer && playerVelocity.y < 0)
        {
            playerVelocity.y = 0f;

        }

        if (!MC_Talking && !MC_Spawning && !MC_Police)
        {
            Vector3 move = new Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical"));
            controller.Move(move * Time.deltaTime * playerSpeed);

            //walking anim ---- Credit: Jack https://twitter.com/JackCL
            float walkDelay = 0.55f;
            if ((move.x != 0 || move.z != 0) && walkTimer > walkDelay)
            {
                walkTimer = 0.0f;
                model.DOPunchPosition(new Vector3(0, .5f, 0), walkDelay, 1, 1);
            }
            walkTimer += Time.deltaTime;
            if (walkTimer > 4.0f)
                walkTimer = walkDelay;

            if (move.x > 0.2f && flip)
            {
                flip = false;
                flipAnim.DOPlayForward();
            }
            if (move.x < -0.2f && !flip)
            {
                flip = true;
                flipAnim.DOPlayBackwards();
            }
        }

        playerVelocity.y += gravityValue * Time.deltaTime;
        controller.Move(playerVelocity * Time.deltaTime);

        //Pause menu control
        if (Input.GetButtonDown("Pause") || Input.GetButtonDown("Exit"))
        {
            if (!UI_PauseMenu.activeSelf)
            {
                UI_PauseMenu.SetActive(true);

                Time.timeScale = 0;
                UI_PauseMenuScript.StartPause();
                UI_PauseMenuScript.OnHomeClick(true);
                MC_Paused = true;
            }
            else //pause menu active
            {

                UI_PauseMenu.SetActive(false);
                Time.timeScale = 1;
                MC_Paused = false;
                UI_PauseMenuScript.EndPause();
            }

        }

        //Opens the evidence page in the pause menu
        if (Input.GetButtonDown("Evidence"))
        {
            Evidence();
        }

        //Conmtrols visibility of the on screen text
        if (Input.GetButtonDown("Text") && !MC_Paused)
            UI_TextToggle.isOn = !UI_TextToggle.isOn;

        /*
        if (MC_Talking)
        {
            if (!MC_TextBoxMesh_Scaled)
            {
                StartCoroutine(ScaleTextBox());
                MC_TextBoxMesh_Scaled = true;
            }

            if (Input.GetButtonDown("Exit"))
            {
                MC_Talking = false;
                MC_TextBoxMesh_Scaled = false;
                MC_MakingChoice = false;
                MC_ChoiceIndex = 0;
                MC_TextBoxMesh.transform.localScale = new Vector3(0, 0, 0);

                MC_OnScreemText.text = "";
                MC_TextBoxText.text = "";

                MC_ChoiceMeshGroup.SetActive(false);

            }

        }
        */
    }

    //Activates the butlers evidence page
    public void ActivateButler()
    {
        UI_PauseMenuScript.ActivateButler();
    }

    //---- Credit: Jack (CREDIT HOWEVER WANTED HERE)
    public void KeepGoing()
    {
        foreach (var item in ChoiceScripts)
        {
            item.keepGoing = true;
        }
    }

    public void CloseClueIcon()
    {
        UI_ClueImageRef.SetActive(false);
        UI_ClueBackground.SetActive(false);
    }

    //Checks if the player is grounded using a raycast
    public bool Grounded()
    {
        return Physics.Raycast(transform.position, -Vector3.up, MC_DistToGround + 0.1f);
    }

    //Updates the volume of any attached auido when the settings are changed
    public void UpdateVolume(float newMasterVolume, float newMusicVolume, float newSFXVolume)
    {
        newMasterVolume = newMasterVolume / 100;
        newMusicVolume = newMusicVolume / 100;
        newSFXVolume = newSFXVolume / 100;

        AudioSource source = GetComponent<AudioSource>();
        float volume = newMasterVolume * newMusicVolume;
        source.volume = volume;
    }

    public void Jump(int divider)
    {
        playerVelocity.y = Mathf.Sqrt((jumpHeight / divider) * -2f * (gravityValue));
    }

    public void Evidence()
    {
        if (UI_PauseMenu.activeSelf)
        {
            UI_PauseMenu.SetActive(false);
            Time.timeScale = 1;
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = false;
        }
        else
        {
            UI_PauseMenu.SetActive(true);
            Time.timeScale = 0;
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;

            UI_PauseMenuScript.OnEvidenceClick();

        }
    }

    //resets in game text boxes when a conversation is exited
    public void Exit()
    {
        if (MC_TextBoxMesh_Scaled)
            MC_TextBoxMesh.transform.localScale = new Vector3(0, 0, 0);

        MC_Talking = false;
        MC_TextBoxMesh_Scaled = false;
        MC_MakingChoice = false;
        MC_ChoiceIndex = 0;

        MC_OnScreemText.text = "";
        MC_TextBoxText.text = "";

        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }

    //Sets the correct ui images for the npc's and player 
    public void SetUI()
    {

        if (MC_Sprite_Background)
        {
            UI_Image_Background.enabled = true;
            UI_Image_Background.sprite = MC_Sprite_Background;
        }
        else
        {
            UI_Image_Background.enabled = false;
        }

        if (MC_Sprite_Detail_1)
        {
            UI_Image_Detail_1.enabled = true;
            UI_Image_Detail_1.sprite = MC_Sprite_Detail_1;
        }
        else
        {
            UI_Image_Detail_1.enabled = false;
        }

        if (MC_Sprite_Detail_2)
        {
            UI_Image_Detail_2.enabled = true;
            UI_Image_Detail_2.sprite = MC_Sprite_Detail_2;
        }
        else
        {
            UI_Image_Detail_2.enabled = false;
        }

        if (MC_Sprite)
        {
            UI_Image.enabled = true;
            UI_Image.sprite = MC_Sprite;
        }
        else
        {

            UI_Image.enabled = false;
        }

        if (MC_Sprite_Frame)
        {
            UI_Image_Frame.enabled = true;
            UI_Image_Frame.sprite = MC_Sprite_Frame;
        }
        else
        {
            UI_Image_Frame.enabled = false;
        }


    }

    //---- Credit: Jack https://twitter.com/JackCL
    public void CheckFlipMC()
    {
        //unflip to be ready for conversation
        if (flip)
        {
            flipAnim.DOPlayForward();
            flip = false;
        }
    }


    public void ChoiceSet(bool value)
    {
        MC_InChoice = value;
    }

    public bool GetChoice()
    {
        return MC_InChoice;
    }
    public void SetCurrentNPCScript(NPC_DialogueScript script)
    {
        MC_CurrentNPC = script;
    }
    public void PoliceTalk()
    {
        MC_Police = true;
    }

    public void Teleport(Vector3 target)
    {
        controller.enabled = false;
        transform.localPosition = target;
        controller.enabled = true;
    }

    public void Talking(Vector3 target, bool talking)
    {
        MC_Talking = talking;
        Teleport(target);


    }

    //Called when the player makes a time consuming choice using the in game text boxes
    public void PlayerInteraction(string[] textData, string[] choiceData)
    {
        MC_TextData = textData;
        MC_Talking = true;

        int columnIndex = 0;
        int rowIndex = 0;

        MC_ChoiceDataArray = new string[choiceData.Length / 2, 2];

        for (int i = 0; i < choiceData.Length; i++)
        {
            if (choiceData[i] == "~")
            {
                MC_ChoiceDataArray[rowIndex, 1] = "Leave ";
                columnIndex = 0;
                rowIndex++;
            }
            else
            {
                MC_ChoiceDataArray[rowIndex, columnIndex] = choiceData[i];
                columnIndex++;
            }
        }
    }

    //Called when the player makes a time consuming choice using the in game text boxes
    public void MakeChoice(int choiceIndex)
    {
        MC_ChosenText = MC_ChoiceDataArray[MC_ChoiceIndex, choiceIndex];
        MC_MakingChoice = false;
        StartCoroutine(WriteChosenText(MC_ChosenText));
        MC_ChoiceIndex++;
        MC_ChoiceMeshGroup.SetActive(false);


        
        if (MC_InteractionCount < MC_InteractionMax)
        {
            UI_CounterRef.AdvanceTime();
            MC_InteractionCount++;

            if (MC_InteractionCount == MC_InteractionMax)
            {
                MC_PoliceRef.transform.localPosition = new Vector3(-1.9f, 41.9f, 52.4f);
                MC_OfficerArrived = true;
                MC_PoliceRef.GetComponent<NPC_PoliceScript>().DropIn();
            }
        }

    }
    

    //Called when the player makes a time consuming choice using yarnspinner
    [YarnCommand("yarn_choice")]
    public void YarnChoice()
    {
        if (MC_InteractionCount < MC_InteractionMax)
        {
            UI_CounterRef.AdvanceTime();
            MC_InteractionCount++;

            //if the max interations for a run are met, spawn in the police officer
            if (MC_InteractionCount == MC_InteractionMax)
            {
                MC_PoliceRef.transform.localPosition = new Vector3(-1.9f, 41.9f, 52.4f);
                MC_OfficerArrived = true;
                MC_PoliceRef.GetComponent<NPC_PoliceScript>().DropIn();
            }
        }

    }

    //Writes the choices the player has to the text boxes
    public void PlayerTalk(int index)
    {
        MC_ChoiceMeshGroup.SetActive(true);

        MC_MakingChoice = true;

        StartCoroutine(WriteChoices(0, MC_ChoiceIndex));
        StartCoroutine(WriteChoices(1, MC_ChoiceIndex));

    }

    public void PlayerTalk(string text)
    {
        StartCoroutine(WriteChosenText(text));
    }

    //Runs the starter yarn file for the player 
    IEnumerator StarterSpeech()
    {

        SetUI();
        NPC_Runner.Stop();
        if (!MainMenuData.RunOnce)
        {
            NPC_Runner.startNode = "Start_Tsuki";
        }
        else
        {
            NPC_Runner.startNode = "Start2_Tsuki";
        }
        yield return new WaitForSeconds(3.0f);
        StartCoroutine(ScaleTextBox());
        NPC_Runner.StartDialogue(NPC_Runner.startNode);


        yield return new WaitForSeconds(0.1f);

    }

    IEnumerator ScaleTextBox()
    {
        /*for (int i = 0; i <= 70; i++)
        {
            MC_TextBoxMesh.transform.localScale = new Vector3(0.2f * i, 0.2f * i, 1);
            yield return new WaitForSeconds(0.001f);

            if (i == 70)
            {
                for (int j = 70; j > 60; j--)
                {
                    MC_TextBoxMesh.transform.localScale = new Vector3(0.2f * j, 0.2f * j, 1);


                    if (j == 61)
                        MC_TextBoxMesh_Scaled = true;


                    yield return new WaitForSeconds(0.001f);
                }
            }

        }*/
        MC_TextBoxMesh.transform.localScale = new Vector3(200, 200, 200);
        yield return new WaitForSeconds(0.1f);

    }

    /*
    IEnumerator WriteText(int index)
    {
        for (int i = 0; i < MC_TextData[index].Length; i++)
        {

            MC_TextBoxText.text = MC_TextData[index].Substring(0, i);

            if (i == MC_TextData[index].Length)
            {

                StopCoroutine(WriteText(index));


            }
            yield return new WaitForSeconds(0.01f);
        }
    }
    */
    IEnumerator WriteChoices(int choiceTextBox, int choiceIndex)
    {
        for (int i = 0; i < MC_ChoiceDataArray[choiceIndex, choiceTextBox].Length; i++)
        {

            MC_ChoiceText[choiceTextBox].text = MC_ChoiceDataArray[choiceIndex, choiceTextBox].Substring(0, i);
            yield return new WaitForSeconds(0.01f);
        }
    }
    

    //Writes a specific string to the player text bopx
    IEnumerator WriteChosenText(string chosenText)
    {
        for (int i = 0; i < chosenText.Length; i++)
        {

            MC_TextBoxText.text = chosenText.Substring(0, i);

            yield return new WaitForSeconds(0.04f);
        }
    }

    //Resets the player at the end of a conversation
    [YarnCommand("end_speech")]
    public void EndSpeech()
    {
        MC_TextBoxMesh.transform.localScale = new Vector3(0, 0, 0);
        MC_TextBoxMesh_Scaled = false;
        MC_OnScreemText.text = "";
        MC_TextBoxText.text = "";
        MC_Spawning = false;

    }



}



