using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DIAG_PlayerChoice : MonoBehaviour
{
    //Check Data

    public Material OBJ_NewMat;
    Material OBJ_StarterMat;

    [SerializeField] MC_Controller MC_ScriptReference;
    [SerializeField] bool DIAG_ChoiceOne;
    
    public bool keepGoing = false;

    //Changes material based on hover state
    private void Start()
    {
        OBJ_StarterMat = GetComponent<Renderer>().material;
    }

    //Changes material based on hover state
    private void OnMouseEnter()
    {
        GetComponent<Renderer>().material = OBJ_NewMat;
    }

    //Calls the choice functions in the MC_Contoller when an in game choice is made
    private void OnMouseOver()
    {
        if (Input.GetButtonDown("Click"))
        { 
            MC_ScriptReference.MC_CurrentNPC.PlayerChoice(DIAG_ChoiceOne);
            MC_ScriptReference.MC_CurrentNPC.OpenChoices(false, "", "");
        }
    }

    //Changes material based on hover state
    private void OnMouseExit()
    {
        GetComponent<Renderer>().material = OBJ_StarterMat;

    }
}
