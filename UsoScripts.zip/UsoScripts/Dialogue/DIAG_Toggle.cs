using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DIAG_Toggle : MonoBehaviour
{
    [SerializeField] GameObject LineView;
    [SerializeField] GameObject OptionsView;
    [SerializeField] CanvasGroup OptionsViewCanvas;
    [SerializeField] Toggle Toggle;
    [SerializeField] GameObject TextIcon;

    [SerializeField] MC_Controller MC;


    //Toggles the on screen text on or off
    public void TextToggle()
    {

        LineView.SetActive(Toggle.isOn);

        if(MC.GetChoice())
            OptionsView.SetActive(Toggle.isOn);
       

        if (Toggle.isOn && MC.GetChoice())
        {
            OptionsViewCanvas.interactable = Toggle.isOn;
            OptionsViewCanvas.blocksRaycasts = Toggle.isOn;
            OptionsViewCanvas.alpha = 1;
        }
        else
        {
            OptionsViewCanvas.alpha = 0;
            OptionsViewCanvas.interactable = Toggle.isOn;
            OptionsViewCanvas.blocksRaycasts = Toggle.isOn;
        }

        if (Toggle.isOn)
        {
            TextIcon.SetActive(false);
            OptionsViewCanvas.alpha = 1;
        }
        else
        { 
            TextIcon.SetActive(true); 
            OptionsViewCanvas.alpha = 0;

        }

    }

    private void Update()
    {
        if (!Toggle.isOn)
        {
            OptionsViewCanvas.alpha = 0;
            OptionsViewCanvas.interactable = false;
            OptionsViewCanvas.blocksRaycasts = false;
        }
    }
}
